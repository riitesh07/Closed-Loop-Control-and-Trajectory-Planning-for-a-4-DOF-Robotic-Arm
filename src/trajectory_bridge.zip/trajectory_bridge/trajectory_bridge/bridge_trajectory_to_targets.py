#!/usr/bin/env python3
import math
import time
from typing import Dict, List, Optional

import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.qos import qos_profile_sensor_data
from rclpy.executors import MultiThreadedExecutor

from std_msgs.msg import Float64MultiArray, Float64
from sensor_msgs.msg import JointState
from control_msgs.action import FollowJointTrajectory


def now_sec(node: Node) -> float:
    return node.get_clock().now().nanoseconds * 1e-9


def ang_err(a: float, b: float) -> float:
    # shortest angular error (rad)
    return math.atan2(math.sin(a - b), math.cos(a - b))


class MoveItTeensyBridge(Node):
    def __init__(self):
        super().__init__("moveit_teensy_bridge")

        # Must match URDF + MoveIt controller joint order:
        self.arm_joints: List[str] = self.declare_parameter(
            "arm_joints", ["continuous", "revolute1", "revolute2"]
        ).value
        self.gripper_joints: List[str] = self.declare_parameter(
            "gripper_joints", ["revolute3"]
        ).value

        # Teensy command topics (micro-ROS subscribers):
        self.arm_cmd_topic = self.declare_parameter(
            "arm_cmd_topic", "/teensy_joint_targets"
        ).value
        self.grip_cmd_topic = self.declare_parameter(
            "grip_cmd_topic", "/teensy_gripper_angle_target"
        ).value

        # Teensy joint states topic (micro-ROS publisher):
        self.js_in_topic = self.declare_parameter(
            "js_in_topic", "/teensy/joint_states"
        ).value
        # RViz expects /joint_states
        self.js_out_topic = self.declare_parameter(
            "js_out_topic", "/joint_states"
        ).value

        # streaming + tolerance
        self.stream_hz = float(self.declare_parameter("stream_hz", 50.0).value)
        self.goal_tol = float(self.declare_parameter("goal_tolerance_rad", 0.06).value)  # ~3.4°
        self.state_timeout = float(self.declare_parameter("state_timeout_sec", 0.6).value)

        # pubs
        self.arm_pub = self.create_publisher(Float64MultiArray, self.arm_cmd_topic, 10)
        self.grip_pub = self.create_publisher(Float64, self.grip_cmd_topic, 10)

        # joint state relay
        self.js_pub = self.create_publisher(JointState, self.js_out_topic, qos_profile_sensor_data)
        self.js_sub = self.create_subscription(JointState, self.js_in_topic, self._on_js, qos_profile_sensor_data)

        self.last_js: Optional[JointState] = None
        self.last_js_time: float = 0.0

        # Action servers (MoveIt will call these)
        self.arm_as = ActionServer(
            self,
            FollowJointTrajectory,
            "/arm_controller/follow_joint_trajectory",
            goal_callback=self._arm_goal_cb,
            cancel_callback=self._cancel_cb,
            execute_callback=self._arm_execute_cb,
        )

        self.grip_as = ActionServer(
            self,
            FollowJointTrajectory,
            "/gripper_controller/follow_joint_trajectory",
            goal_callback=self._grip_goal_cb,
            cancel_callback=self._cancel_cb,
            execute_callback=self._grip_execute_cb,
        )

        self.get_logger().info("MoveIt ↔ Teensy bridge ready.")
        self.get_logger().info(f"Arm joints: {self.arm_joints}  cmd={self.arm_cmd_topic}")
        self.get_logger().info(f"Grip joints: {self.gripper_joints} cmd={self.grip_cmd_topic}")
        self.get_logger().info(f"JointStates in={self.js_in_topic} out={self.js_out_topic}")

    # ---------- joint state ----------
    def _on_js(self, msg: JointState):
        self.last_js = msg
        self.last_js_time = now_sec(self)
        self.js_pub.publish(msg)

    def _fresh_state_ok(self) -> bool:
        if self.last_js is None:
            return False
        return (now_sec(self) - self.last_js_time) <= self.state_timeout

    def _pos_map(self) -> Optional[Dict[str, float]]:
        if self.last_js is None:
            return None
        if len(self.last_js.name) != len(self.last_js.position):
            return None
        return dict(zip(self.last_js.name, self.last_js.position))

    # ---------- action callbacks ----------
    def _cancel_cb(self, goal_handle):
        self.get_logger().warn("Cancel requested.")
        return CancelResponse.ACCEPT

    def _arm_goal_cb(self, goal_request):
        if list(goal_request.trajectory.joint_names) != list(self.arm_joints):
            self.get_logger().error(
                f"ARM joint mismatch got={goal_request.trajectory.joint_names} expected={self.arm_joints}"
            )
            return GoalResponse.REJECT
        return GoalResponse.ACCEPT

    def _grip_goal_cb(self, goal_request):
        if list(goal_request.trajectory.joint_names) != list(self.gripper_joints):
            self.get_logger().error(
                f"GRIP joint mismatch got={goal_request.trajectory.joint_names} expected={self.gripper_joints}"
            )
            return GoalResponse.REJECT
        return GoalResponse.ACCEPT

    def _wait_reached(self, names: List[str], targets: List[float], timeout: float) -> bool:
        t0 = time.time()
        while (time.time() - t0) < timeout:
            pm = self._pos_map()
            if pm and all(n in pm for n in names):
                ok = True
                for n, tgt in zip(names, targets):
                    if abs(ang_err(pm[n], tgt)) > self.goal_tol:
                        ok = False
                        break
                if ok:
                    return True
            time.sleep(0.02)
        return False

    def _arm_execute_cb(self, goal_handle):
        traj = goal_handle.request.trajectory
        if not traj.points:
            goal_handle.abort()
            res = FollowJointTrajectory.Result()
            res.error_code = FollowJointTrajectory.Result.INVALID_GOAL
            return res

        if not self._fresh_state_ok():
            self.get_logger().warn("No fresh /teensy/joint_states (still streaming commands).")

        pts = traj.points
        times = [p.time_from_start.sec + p.time_from_start.nanosec * 1e-9 for p in pts]
        T = times[-1]
        start = time.time()
        dt = 1.0 / self.stream_hz

        def sample(t: float) -> List[float]:
            if t <= times[0]:
                return list(pts[0].positions)
            if t >= times[-1]:
                return list(pts[-1].positions)
            for i in range(len(times) - 1):
                t0, t1 = times[i], times[i + 1]
                if t0 <= t <= t1:
                    u = 0.0 if (t1 - t0) < 1e-6 else (t - t0) / (t1 - t0)
                    p0 = pts[i].positions
                    p1 = pts[i + 1].positions
                    return [p0[j] + (p1[j] - p0[j]) * u for j in range(len(p0))]
            return list(pts[-1].positions)

        # stream
        while True:
            if goal_handle.is_cancel_requested:
                goal_handle.canceled()
                res = FollowJointTrajectory.Result()
                res.error_code = FollowJointTrajectory.Result.SUCCESSFUL
                return res

            t = time.time() - start
            cmd = sample(t)

            msg = Float64MultiArray()
            msg.data = cmd  # radians
            self.arm_pub.publish(msg)

            if t >= T:
                break
            time.sleep(dt)

        # wait for reach (uses Teensy joint_states)
        target = list(pts[-1].positions)
        reached = self._wait_reached(self.arm_joints, target, timeout=max(1.0, 1.5 * T + 0.6))
        if not reached:
            goal_handle.abort()
            res = FollowJointTrajectory.Result()
            res.error_code = FollowJointTrajectory.Result.GOAL_TOLERANCE_VIOLATED
            return res

        goal_handle.succeed()
        res = FollowJointTrajectory.Result()
        res.error_code = FollowJointTrajectory.Result.SUCCESSFUL
        return res

    def _grip_execute_cb(self, goal_handle):
        traj = goal_handle.request.trajectory
        if not traj.points:
            goal_handle.abort()
            res = FollowJointTrajectory.Result()
            res.error_code = FollowJointTrajectory.Result.INVALID_GOAL
            return res

        tgt = float(traj.points[-1].positions[0])  # radians
        m = Float64()
        m.data = tgt
        self.grip_pub.publish(m)

        reached = self._wait_reached(self.gripper_joints, [tgt], timeout=2.5)
        if not reached:
            goal_handle.abort()
            res = FollowJointTrajectory.Result()
            res.error_code = FollowJointTrajectory.Result.GOAL_TOLERANCE_VIOLATED
            return res

        goal_handle.succeed()
        res = FollowJointTrajectory.Result()
        res.error_code = FollowJointTrajectory.Result.SUCCESSFUL
        return res


def main():
    rclpy.init()
    node = MoveItTeensyBridge()
    executor = MultiThreadedExecutor(num_threads=4)
    executor.add_node(node)
    try:
        executor.spin()
    finally:
        executor.shutdown()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()

